% Name: Twymun K. Safford
% Class: MATH 352
% Assignment: Homework 2, Section 2.6, Problem 3a

%Implementation of Muller Method to aproximate roots
%within range of 10^-4 for f(x) = x^3 - 2x^2 - 5

function y=Muller()
  f=@(x) x^3-2*x^2-5;
  tol = 10^(-5);
  N0 = 10;
  p0=1.5;
  p1=2;
  p2=2.5;
  h1=p1-p0;
  h2=p2-p1;
  delta1=(f(p1)-f(p0))/h1;
  delta2=(f(p2)-f(p1))/h2;
  d=(delta2-delta1)/(h2+h1);
  
  for i=3:N0
    b=delta2+h2*d;
    D=sqrt(b^2-4*f(p2)*d);
    
    if abs(b-D)<abs(b+D)
      E=b+D;
    else 
      E=b-D;
    end
    
    h=-2*f(p2)/E;
    p=p2+h;
    fprintf("%d %10g%+g i %20g%+g i\n", i,real(p),imag(p),real(f(p)),imag(f(p)));
    
    if abs(h)<tol
      y=p;
      return
    end
    
    p0=p1;
    p1=p2;
    p2=p;
    h1=p1-p0;
    h2=p2-p1;
    delta1=(f(p1)-f(p0))/h1;
    delta2=(f(p2)-f(p1))/h2;
    d=(delta2-delta1)/(h2+h1);
  end
  
end
